clear, clc, close all;

disp('กำลังโหลดข้อมูลฟีเจอร์ความละเอียดสูง (252 ฟีเจอร์)...');
load feaAllTrain feaTrain LebelAllTrain
load feaAllTest feaTest LebelAllTest

%% 1. ตรวจสอบและทำความสะอาดข้อมูล (Data Cleaning แยก Train/Test)
disp('กำลังทำความสะอาดข้อมูล (ลบ NaN/Inf)...');
% ชุด Train
bad_rows_train = any(isnan(feaTrain) | isinf(feaTrain), 2);
feaTrain(bad_rows_train, :) = [];
LebelAllTrain(bad_rows_train) = [];

% ชุด Test
bad_rows_test = any(isnan(feaTest) | isinf(feaTest), 2);
feaTest(bad_rows_test, :) = [];
LebelAllTest(bad_rows_test) = [];

%% 2. เตรียมข้อมูลสำหรับฝึกสอน (Training Data)
disp('กำลังเตรียมข้อมูล Train...');
% สลับเมทริกซ์ให้ตรงกับรูปแบบที่ Neural Network Toolbox ต้องการ (Features x Samples)
XTrain = feaTrain';
YTrain = dummyvar(LebelAllTrain)'; % แปลงเป็น One-hot encoding

%% 3. การปรับบรรทัดฐาน (Normalization)
disp('กำลังทำ Normalization...');
% คำนวณค่า Mean/Std จากชุด Train และเก็บค่า Settings ไว้
[XTrain_norm, settings] = mapstd(XTrain); 

% นำ Settings ของชุด Train ไปปรับใช้กับชุด Test (ห้ามคำนวณใหม่จากชุด Test เด็ดขาด)
XTest = feaTest';
YTest = dummyvar(LebelAllTest)';
XTest_norm = mapstd('apply', XTest, settings); 

%% 4. สร้างและฝึกสอนโมเดล (Elman Neural Network)
disp('กำลังสร้างและเทรนโมเดล (Elman Neural Network)...');

% 1. แก้ไขการแปลงข้อมูล (สำคัญมาก): 
% ใช้เครื่องหมายปีกกา {} แทน con2seq เพื่อบอก MATLAB ว่า 
% ข้อมูลทั้งหมดนี้คือเหตุการณ์อิสระ (Concurrent Data) ที่ป้อนเข้ามาพร้อมกันใน 1 ไทม์สเต็ป
XTrain_seq = {XTrain_norm};
YTrain_seq = {YTrain};

% 2. กำหนดขนาด Hidden Layer (ย่อลงเพื่อลดภาระ RAM และลดอาการท่องจำ)
hiddenLayerSize = [64, 32]; 

% 3. สร้าง Elman Network
net = elmannet(1:2, hiddenLayerSize, 'trainscg'); 

% --- 4. ฟังก์ชันพระเอก: เปิดโหมดหารแบ่งหน่วยความจำ ---
% ระบบจะแบ่งข้อมูลคำนวณเป็นส่วนๆ แทนการคำนวณก้อนใหญ่ก้อนเดียว (แก้ปัญหา RAM เต็ม)
net.efficiency.memoryReduction = 4; % หากยัง Error อีก สามารถปรับเพิ่มเป็น 8 หรือ 16 ได้
% --------------------------------------------------

% แบ่งข้อมูล Train ภายในเพื่อป้องกัน Overfitting (Early Stopping)
net.divideParam.trainRatio = 0.85; 
net.divideParam.valRatio   = 0.15; 
net.divideParam.testRatio  = 0.0;  

% ตั้งค่าพารามิเตอร์การเทรน
net = configure(net, XTrain_seq, YTrain_seq);
net.performFcn = 'crossentropy'; 
net.layers{net.numLayers}.transferFcn = 'softmax';
net.trainParam.epochs = 1000;
net.trainParam.min_grad = 1e-6; 
net.trainParam.max_fail = 20;   
net.trainParam.showWindow = true; 

% รันกระบวนการเทรน
[net, tr] = train(net, XTrain_seq, YTrain_seq);
disp('เทรนโมเดลเสร็จสิ้น!');

%% 5. ทดสอบโมเดลด้วย Unseen Data (Testing)
disp('กำลังประเมินผลประสิทธิภาพกับชุด Test (Unseen Data)...');

% แปลงข้อมูล Test ด้วยปีกกาเช่นเดียวกัน
XTest_seq = {XTest_norm};

% ให้โมเดลทำนายผล
YPred_seq = net(XTest_seq); 

% ดึงเมทริกซ์ 2 มิติออกมาจาก Cell Array เพื่อนำไปเข้า Confusion Matrix
YPred = YPred_seq{1};

%% 6. ประเมินประสิทธิภาพ (Evaluation)
[~, classPred] = max(YPred);
[~, classTrue] = max(YTest);

% สร้าง Confusion Matrix จากชุด Test เท่านั้น
C = confusionmat(classTrue, classPred);
TP = diag(C);
FP = sum(C, 1)' - TP;
FN = sum(C, 2) - TP;
TN = sum(C(:)) - (TP + FP + FN);

Precision   = TP ./ (TP + FP);
Recall      = TP ./ (TP + FN); 
Sensitivity = Recall;
Specificity = TN ./ (TN + FP);
F_Measure   = 2 .* (Precision .* Recall) ./ (Precision + Recall);

% จัดการกรณีส่วนเป็น 0 (NaN)
Precision(isnan(Precision)) = 0;
Sensitivity(isnan(Sensitivity)) = 0;
Specificity(isnan(Specificity)) = 0;
F_Measure(isnan(F_Measure)) = 0;

Overall_Accuracy = (sum(TP) / sum(C(:))) * 100;
Macro_Precision = mean(Precision) * 100;
Macro_Sensitivity = mean(Sensitivity) * 100;
Macro_Specificity= mean(Specificity) * 100;
Macro_F_Measure = mean(F_Measure) * 100;

p0 = sum(diag(C)) / sum(C(:)); 
pe = sum(sum(C, 1) .* sum(C, 2)') / (sum(C(:))^2); 
Kappa_Score = (p0 - pe) / (1 - pe);

% ดึงค่าสถิติจากกระบวนการ Normalization
Mean_all = settings.xmean; 
SD_all   = settings.xstd;

disp('======================================================');
disp('   ประสิทธิภาพของโมเดล (ทดสอบกับ Test Set ที่แยกไว้)   ');
disp('======================================================');
fprintf('Accuracy      : %.2f %%\n', Overall_Accuracy);
fprintf('Precision     : %.2f %%\n', Macro_Precision);
fprintf('Sensitivity   : %.2f %%\n', Macro_Sensitivity);
fprintf('Specificity   : %.2f %%\n', Macro_Specificity);
fprintf('F-Measure     : %.2f %%\n', Macro_F_Measure);
fprintf('Kappa Score   : %.4f\n', Kappa_Score);
disp('------------------------------------------------------');
disp('   ค่าสถิติจากกระบวนการ Normalization (อ้างอิงจากชุด Train) ');
disp('------------------------------------------------------');
fprintf('Avg Mean (ภาพรวม %d ฟีเจอร์) : %.4f\n', length(Mean_all), mean(Mean_all));
fprintf('Avg SD   (ภาพรวม %d ฟีเจอร์) : %.4f\n', length(SD_all), mean(SD_all));
disp('======================================================');

% เซฟไฟล์โมเดลและเมทริกซ์รวมถึงค่า Mean, SD เผื่อการใช้งานภายหลัง
save allMetrics Overall_Accuracy Macro_Precision Macro_Sensitivity Macro_Specificity Macro_F_Measure Kappa_Score Mean_all SD_all
save trained_model.mat net settings