clc; clear; close all;
% กำหนดที่อยู่โฟลเดอร์ข้อมูล (Path) ตามที่ระบุ
trainDir = 'K:\Brain_Stroke_Image\Train';
% testDir  = 'D:\Project\archive\Test';

% ใช้ imageDatastore โหลดภาพและดึง Label จากชื่อโฟลเดอร์ย่อย
imdsTrain = imageDatastore(trainDir, 'IncludeSubfolders', true, 'LabelSource', 'foldernames'); 
% imdsTest  = imageDatastore(testDir, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');

disp(['จำนวนภาพสำหรับ Train: ', num2str(numel(imdsTrain.Files))]); % แสดงจำนวนภาพที่อยู่ในโฟลเดอร์
% disp(['จำนวนภาพสำหรับ Test: ', num2str(numel(imdsTest.Files))]);

% กระบวนการ Feature Extraction สำหรับข้อมูล Train
disp('กำลังสกัดคุณลักษณะ (Feature Extraction) สำหรับ Train Data...');
numTrain = numel(imdsTrain.Files); % เก็บค่าจำนวนเต็มของภาพที่อยู่ในโฟลเดอร์ไว้ในตัวแปร numTrain

%% 1. Input brain stroke CT images
feaTrain = [];

for i = 1:numTrain % เริ่มต้นลูป
    disp(['Processing Image: ', num2str(i), '/', num2str(numTrain)]); % แสดงสถานะการรัน
    img = readimage(imdsTrain, i); % ดึงรูปภาพลำดับที่ i มาเก็บใน RAM ในชื่อตัวแปร img

    if size(img, 3) == 3 % เช็คว่าภาพนี้มีมิติ = 3 หรือไม่ (3 = RGB(แดง, เขียว, น้ำเงิน))
        img = rgb2gray(img); % แปลงรูปเป็นสีเทา (grayscale)
    end
    img = imresize(img, [256 256]); % ตั้งขนาดรูปเป็น best practice (ไม่มีกำหนดขนาดรูปในเปเปอร์)

    %% --- เทคนิคหน้ากากวงรี (Elliptical Mask) ---
    [rows, cols] = size(img);
    [X_grid, Y_grid] = meshgrid(1:cols, 1:rows);
    centerX = cols/2; centerY = rows/2;
    
    % ปรับขนาดวงรีให้พอดีกับรูปทรงศีรษะ
    radiusX = cols * 0.40; % รัศมีแนวนอน 40% (ตัดขอบซ้ายขวา)
    radiusY = rows * 0.48; % รัศมีแนวตั้ง 48% (รักษาขอบบนล่างไว้เกือบสุด)
    
    % สร้างสมการวงรี
    elliptical_mask = ((X_grid - centerX).^2 / radiusX^2) + ((Y_grid - centerY).^2 / radiusY^2) <= 1;
    
    % นำหน้ากากไปคูณกับรูปภาพ
    img = uint8(double(img) .* elliptical_mask);
    %% ------------------------------------------------

    %% 2. Pre-processing: Wiener Filter
    filtered_img = wiener2(img, [5 5]);

    % พอตรูป
    % figure;
    % imshow(img,[]);
    % drawnow;

    % โค้ดสำหรับพล็อต 2 รูปคู่กันซ้าย-ขวา
    % figure;
    % subplot(1,2,1); imshow(img, []);
    % subplot(1,2,2); imshow(filtered_img, []);
    % drawnow;

    %% 3. Segmentation (EM)
    img_norm = mat2gray(double(filtered_img)); 
    X = img_norm(:); 
    
    K = 5; 
    maxIter = 100; 
    N = length(X);
    
    rng(1);
    mu = linspace(min(X), max(X), K); 
    sigma = ones(1,K) * var(X); 
    pi_k = ones(1,K) / K; 
    gamma = zeros(N, K); 
    
    for iter = 1:maxIter
        for k = 1:K
            var_k = max(sigma(k), 1e-6); 
            gamma(:,k) = pi_k(k) * (1 ./ sqrt(2*pi*var_k)) .* exp(-(X - mu(k)).^2 ./ (2*var_k));
        end
        gamma_sum = sum(gamma,2);
        gamma_sum(gamma_sum == 0) = 1e-6; 
        gamma = gamma ./ gamma_sum;
        
        Nk = sum(gamma);
        for k = 1:K
            mu(k) = sum(gamma(:,k) .* X) / max(Nk(k), 1e-6); 
            sigma(k) = sum(gamma(:,k) .* (X - mu(k)).^2) / max(Nk(k), 1e-6);
            pi_k(k) = Nk(k) / N;
        end
    end
    
    [~, labels] = max(gamma, [], 2);
    
    % เรียงลำดับความสว่าง เพื่อหาพื้นหลังสีดำ (คลัสเตอร์ที่มืดที่สุด)
    [~, sort_idx] = sort(mu, 'ascend');
    background_cluster = sort_idx(1);
    
    % สร้าง Mask ที่ดึง "เนื้อสมองทั้งหมด" (เอาทุกอย่างที่ไม่ใช่พื้นหลัง)
    % วิธีนี้จะเก็บรอยโรคไว้ได้ครบทั้ง Ischemia (มืด) และ Hemorrhage (สว่าง)
    brain_mask = reshape((labels ~= background_cluster), size(img_norm));
    roi_img = double(filtered_img) .* double(brain_mask);

    % figure;
    % imshow(roi_img, []);
    % drawnow;

    %% 4. Feature Extraction (DCT, DWT, GLCM)
    % ตีกรอบ Bounding Box เฉพาะเนื้อสมอง เพื่อกำจัดพิกเซลสีดำส่วนเกิน
    [r, c] = find(brain_mask); 
    if ~isempty(r)
        cropped_roi = roi_img(min(r):max(r), min(c):max(c));
        cropped_roi = imresize(cropped_roi, [128 128]); % คงขนาด 128x128 เพื่อรักษา Texture
    else
        cropped_roi = zeros(128, 128);
    end

    % 1. Asymmetry Feature (ความไม่สมมาตร ซ้าย-ขวา)
    [h, w] = size(cropped_roi);
    left_half = cropped_roi(:, 1:floor(w/2));
    right_half = cropped_roi(:, floor(w/2)+1:end);
    left_vec = left_half(left_half > 0);
    right_vec = right_half(right_half > 0);
    mean_L = 0; if ~isempty(left_vec), mean_L = mean(left_vec); end
    mean_R = 0; if ~isempty(right_vec), mean_R = mean(right_vec); end
    f_asymmetry = abs(mean_L - mean_R); % ผลต่างความสว่างซีกซ้ายและขวา

    % 2. DCT Features
    dct_coeffs = dct2(cropped_roi);
    f_dct_mean = mean(abs(dct_coeffs(:)));
    f_dct_var  = var(dct_coeffs(:));
    
    % 3. Full DWT Features (ดึงค่า Detail ขอบรอยโรค)
    [cA, cH, cV, cD] = dwt2(cropped_roi, 'haar');
    f_dwt_mean_cA = mean(cA(:));
    f_dwt_var_cA  = var(cA(:));
    f_dwt_var_cH  = var(cH(:)); % ขอบแนวนอน
    f_dwt_var_cV  = var(cV(:)); % ขอบแนวตั้ง
    f_dwt_var_cD  = var(cD(:)); % ขอบทแยง
     
    % 4. GLCM Texture Features (4 ทิศทาง)
    roi_uint8 = uint8(255 * mat2gray(cropped_roi));
    offsets = [0 1; -1 1; -1 0; -1 -1]; 
    glcm = graycomatrix(roi_uint8, 'Offset', offsets, 'NumLevels', 8, 'Symmetric', true);
    glcm_stats = graycoprops(glcm, {'Contrast', 'Energy', 'Homogeneity', 'Correlation'});
    f_contrast = mean(glcm_stats.Contrast);
    f_energy   = mean(glcm_stats.Energy);
    f_homo     = mean(glcm_stats.Homogeneity);
    f_corr     = mean(glcm_stats.Correlation);
    
    % 5. Intensity & Statistical Features
    roi_vector = cropped_roi(cropped_roi > 0); 
    if isempty(roi_vector)
        roi_vector = 0;
    end
    f_mean = mean(roi_vector);
    f_std  = std(double(roi_vector));
    f_skew = skewness(double(roi_vector));
    f_kurt = kurtosis(double(roi_vector)); % เพิ่ม Kurtosis
    f_entropy = entropy(uint8(255 * mat2gray(cropped_roi))); % เพิ่ม Entropy
    
    % รวมฟีเจอร์ทั้งหมดเป็น 17 ตัว
    features = [f_dct_mean, f_dct_var, f_dwt_mean_cA, f_dwt_var_cA, f_dwt_var_cH, f_dwt_var_cV, f_dwt_var_cD, ...
                f_contrast, f_energy, f_homo, f_corr, f_mean, f_std, f_skew, f_kurt, f_entropy, f_asymmetry];
    feaTrain = [feaTrain; features]; % นำฟีเจอร์มาต่อกันเป็นคอลัมน์
end
% class 1 = hemorrhage class 2 = ischemia class 3 = normal
LebelAllTrain = [ones(4000,1); ones(4000,1)*2; ones(4000,1)*3];
save feaAllTrain feaTrain LebelAllTrain
disp('--- สกัดฟีเจอร์และบันทึกไฟล์เสร็จสมบูรณ์ ---');