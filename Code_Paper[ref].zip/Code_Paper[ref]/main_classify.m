clear,clc
% โหลดข้อมูลที่สกัดฟีเจอร์ไว้แล้ว
disp('กำลังโหลดข้อมูลฟีเจอร์...');
load feaAllTrain feaTrain LebelAllTrain
load feaAllTest feaTest LebelAllTest

% แปลง Label เป็นรูปแบบ One-Hot Encoding สำหรับ Neural Network
XTrain = feaTrain';
YTrain = dummyvar(LebelAllTrain)';

% การทำ Normalization (ปรับสเกลฟีเจอร์)
% ปรับให้ตัวเลขทุกฟีเจอร์อยู่ในช่วง -1 ถึง 1 เพื่อให้ AI เรียนรู้ได้ดีขึ้น
[XTrain_norm, settings] = mapminmax(XTrain);

%% 5. การสร้างและเทรนโมเดล (Neural Network Training)
disp('กำลังสร้างและเทรนโมเดล (Training Neural Network)...');

% ใช้ Pattern Recognition Network (patternnet) ซึ่งเหมาะกับงานจำแนกภาพ
hiddenLayerSize = [50, 25]; % จำนวนโหนดใน Hidden Layer

% ใช้ cascadeforwardnet เพื่อให้เกิดการเชื่อมต่อแบบทางลัด (Cascade)
net = cascadeforwardnet(hiddenLayerSize);
% กำหนดอัลกอริทึมการเทรนเป็น Levenberg-Marquardt ซึ่งเป็นกระบวนการ Optimized ที่ดีที่สุด
net.trainFcn = 'trainscg';

% ตั้งค่าการเทรน
net.trainParam.epochs = 2000;
net.trainParam.goal = 1e-6;
net.trainParam.min_grad = 1e-7; % ลดเกณฑ์การหยุดเพื่อให้โมเดลลู่เข้าหาคำตอบที่ดีที่สุด
net.trainParam.max_fail = 30; % อนุญาตให้ฟังก์ชันทดสอบพลาดได้มากขึ้นก่อนบังคับหยุดเทรน
net.trainParam.showWindow = true; % เปิดหน้าต่างดูสถานะการเทรน

% รันคำสั่งเทรน
[net, tr] = train(net, XTrain_norm, YTrain);
disp('เทรนโมเดลเสร็จสิ้น!');

%% 6. กระบวนการทดสอบ (Testing / Inference)
disp('กำลังทดสอบโมเดลกับข้อมูล Test...');

% เตรียมข้อมูลทดสอบจากไฟล์ .mat (ข้ามกระบวนการสกัดข้อมูลใหม่)
XTest = feaTest';
YTest = dummyvar(LebelAllTest)';
XTest_norm = mapminmax('apply', XTest, settings);

% ทำนายผล
YPred = net(XTest_norm);

%% 7. ประเมินประสิทธิภาพ (Evaluation)
% แปลงค่าความน่าจะเป็นกลับเป็นคลาส
[~, classPred] = max(YPred);
[~, classTrue] = max(YTest);

% สร้างตัวแปร Confusion Matrix
C = confusionmat(classTrue, classPred);

% คำนวณ TP, FP, FN, TN สำหรับแต่ละคลาส
TP = diag(C);
FP = sum(C, 1)' - TP;
FN = sum(C, 2) - TP;
TN = sum(C(:)) - (TP + FP + FN);

% คำนวณตัวชี้วัดของแต่ละคลาส
Precision   = TP ./ (TP + FP);
Recall      = TP ./ (TP + FN); 
Sensitivity = Recall;
Specificity = TN ./ (TN + FP);
F_Measure   = 2 .* (Precision .* Recall) ./ (Precision + Recall); % คือ F1-Score

% ดักจับ Error กรณีที่ตัวหารเป็น 0
Precision(isnan(Precision)) = 0;
Sensitivity(isnan(Sensitivity)) = 0;
Specificity(isnan(Specificity)) = 0;
F_Measure(isnan(F_Measure)) = 0;

% คำนวณค่าความแม่นยำและค่าเฉลี่ยรวมของระบบ (เปอร์เซ็นต์)
Overall_Accuracy = (sum(TP) / sum(C(:))) * 100;
Macro_Precision = mean(Precision) * 100;
Macro_Sensitivity = mean(Sensitivity) * 100;
Macro_Specificity= mean(Specificity) * 100;
Macro_F_Measure = mean(F_Measure) * 100;

% คำนวณค่า Cohen's Kappa Score
p0 = sum(diag(C)) / sum(C(:)); 
pe = sum(sum(C, 1) .* sum(C, 2)') / (sum(C(:))^2); 
Kappa_Score = (p0 - pe) / (1 - pe);

% แสดงผลลัพธ์
disp('======================================================');
disp('   ประสิทธิภาพของโมเดล (Performance Evaluation Metrics)   ');
disp('======================================================');
fprintf('Accuracy      : %.2f %%\n', Overall_Accuracy);
fprintf('Precision     : %.2f %%\n', Macro_Precision);
fprintf('Sensitivity   : %.2f %%\n', Macro_Sensitivity);
fprintf('Specificity   : %.2f %%\n', Macro_Specificity);
fprintf('F-Measure     : %.2f %%\n', Macro_F_Measure);
fprintf('Kappa Score   : %.4f\n', Kappa_Score);
disp('======================================================');

save allMetrics Overall_Accuracy Macro_Precision Macro_Sensitivity Macro_Specificity Macro_F_Measure Kappa_Score
